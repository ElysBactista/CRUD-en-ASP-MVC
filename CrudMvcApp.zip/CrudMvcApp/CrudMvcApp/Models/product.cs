﻿namespace CrudMvcApp.Models
{
    public class Product
    {
        public int Id { get; set; } // ID del producto
        public string Name { get; set; } // Nombre del producto
        public decimal Price { get; set; } // Precio del producto
    }
}
